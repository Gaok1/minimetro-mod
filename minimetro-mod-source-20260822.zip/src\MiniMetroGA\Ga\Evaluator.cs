using System;
using System.Collections.Generic;
using MiniMetroGA.Core;

namespace MiniMetroGA.Ga
{
    /// <summary>
    /// Simulador surrogate + funcao de fitness.
    ///
    /// Nao roda o jogo. Constroi um grafo "estacao x linha" e faz Dijkstra a partir
    /// de cada estacao, o que da simultaneamente:
    ///   - tempo de viagem esperado por par (origem, forma de destino)
    ///   - quantas baldeacoes cada viagem exige (o custo ja esta embutido nas arestas)
    ///   - fluxo por linha e por estacao, via reconstrucao dos caminhos
    ///
    /// Modelo de nos:
    ///   no  s                -> plataforma da estacao s (fora do trem)
    ///   no  N + l*N + s      -> dentro do trem da linha l, na estacao s
    /// Arestas:
    ///   plataforma -> dentro : espera (headway/2) + BoardingPenalty
    ///   dentro     -> plataforma : TransferPenalty
    ///   dentro(s,l)-> dentro(s',l) : dist/velocidade + dwell
    ///
    /// Uma instancia por thread (tem buffers mutaveis).
    /// </summary>
    public class Evaluator
    {
        private readonly Snapshot _s;
        private readonly GaConfig _cfg;

        private readonly int _n;
        private readonly int _maxLines;
        private readonly int _nodeCap;

        // adjacencia em lista ligada sobre arrays (zero alocacao por avaliacao)
        private int[] _head;
        private int[] _edgeTo;
        private float[] _edgeW;
        private int[] _edgeLine;    // -1 = embarque/desembarque
        private int[] _edgeNext;
        private int _edgeCount;

        // dijkstra
        private float[] _dist;
        private int[] _prevNode;
        private int[] _prevEdge;
        private bool[] _done;
        private int[] _heap;
        private int[] _heapPos;
        private int _heapSize;

        // acumuladores por avaliacao
        private double[] _onBoard;      // passageiros medios a bordo por linha
        private double[] _waiting;      // passageiros medios esperando por estacao
        private float[] _headwayWait;   // espera media por linha
        private bool[] _served;
        private float[] _cycle;         // tempo de volta completa por linha (0 = linha nao existe)
        private int[] _seats;           // assentos por linha = (locos + vagoes) * RailcarCapacity
        private float[] _crowd;         // multiplicador de espera por lotacao (>= 1)

        private readonly List<int>[] _linesAtStation;

        public Evaluator(Snapshot snap, GaConfig cfg)
        {
            _s = snap;
            _cfg = cfg;
            _n = snap.N;
            _maxLines = Math.Max(1, cfg.MaxLinesOverride > 0
                ? Math.Min(cfg.MaxLinesOverride, snap.LineBudget)
                : snap.LineBudget);

            _nodeCap = _n * (_maxLines + 1);
            int edgeCap = 8 * _maxLines * Math.Max(4, cfg.MaxStationsPerLine) + 16;

            _head = new int[_nodeCap];
            _edgeTo = new int[edgeCap];
            _edgeW = new float[edgeCap];
            _edgeLine = new int[edgeCap];
            _edgeNext = new int[edgeCap];

            _dist = new float[_nodeCap];
            _prevNode = new int[_nodeCap];
            _prevEdge = new int[_nodeCap];
            _done = new bool[_nodeCap];
            _heap = new int[_nodeCap + 1];
            _heapPos = new int[_nodeCap];

            _onBoard = new double[_maxLines];
            _waiting = new double[_n];
            _headwayWait = new float[_maxLines];
            _served = new bool[_n];
            _cycle = new float[_maxLines];
            _seats = new int[_maxLines];
            _crowd = new float[_maxLines];

            _linesAtStation = new List<int>[_n];
            for (int i = 0; i < _n; i++) _linesAtStation[i] = new List<int>(4);
        }

        private int PlatformNode(int s) => s;
        private int RideNode(int s, int l) => _n + l * _n + s;

        public double Evaluate(Genome g)
        {
            g.NormalizeFleet(_s);

            int L = Math.Min(g.RouteCount, _maxLines);
            var bd = new EvalBreakdown();

            float speed = _cfg.TrainSpeedOverride > 0f ? _cfg.TrainSpeedOverride : _s.TrainSpeed;
            if (speed < 1f) speed = 1f;

            // ---- geometria da rede: identica nos dois passes, entao so uma vez ----
            float totalTrack = 0f;
            int crossingsUsed = 0;
            for (int l = 0; l < L; l++)
            {
                _cycle[l] = 0f;
                _seats[l] = 0;
                _crowd[l] = 1f;

                var route = g.Routes[l];
                int m = route.Count;
                if (m < 2) continue;

                // Linha sem trem nao existe: nao atende estacao, nao gera aresta e
                // nao consome trilho. Um Math.Max(1, Locos[l]) aqui fazia o fitness
                // avaliar uma linha parada como se ela tivesse um trem, e o AG nao
                // tinha como perceber que a solucao era impossivel.
                int trains = g.Locos[l];
                if (trains <= 0) continue;

                bool loop = g.Loops[l] && m >= 3;

                float segSum = 0f;
                for (int k = 0; k + 1 < m; k++)
                {
                    segSum += _s.Dist[route[k]][route[k + 1]];
                    if (_s.NeedsCrossing[route[k]][route[k + 1]]) crossingsUsed++;
                }
                if (loop)
                {
                    segSum += _s.Dist[route[m - 1]][route[0]];
                    if (_s.NeedsCrossing[route[m - 1]][route[0]]) crossingsUsed++;
                }
                totalTrack += segSum;

                // tempo de um ciclo completo: ida e volta se nao for loop
                float travel = segSum / speed;
                _cycle[l] = loop
                    ? travel + _cfg.DwellTime * m
                    : 2f * travel + _cfg.DwellTime * 2f * m;

                // capacidade real: locomotiva e vagao sao ambos railcars, e cada um
                // leva RailcarCapacity passageiros (lido do TrainDefinition da cidade).
                _seats[l] = (trains + Math.Max(0, g.Cars[l])) * _s.RailcarCapacity;
            }

            // ---- roteamento, com realimentacao de lotacao ----
            //
            // Passe 1 assume que sempre cabe todo mundo no primeiro trem. Passe 2
            // corrige: numa linha com o dobro de passageiros do que assentos voce
            // deixa um trem passar, entao a espera dobra. Sem esse segundo passe a
            // capacidade nao entrava no tempo de viagem de ninguem - a unica coisa
            // que os vagoes mexiam era a penalidade de congestionamento, que quase
            // nunca disparava. Resultado: vagao nao tinha gradiente nenhum e o AG
            // espalhava vagao a esmo, ignorando por onde a linha passa e a demanda.
            double travelCost = 0, unreachableCost = 0;
            double demandTotal = 0, weightedTime = 0;
            int unreachablePairs = 0;

            int passes = _cfg.CapacityFeedback ? 2 : 1;
            for (int pass = 0; pass < passes; pass++)
            {
                travelCost = 0; unreachableCost = 0;
                demandTotal = 0; weightedTime = 0; unreachablePairs = 0;

                ResetGraph();
                BuildGraph(g, L, speed);
                RouteDemand(ref travelCost, ref unreachableCost, ref demandTotal,
                            ref weightedTime, ref unreachablePairs);

                if (pass + 1 < passes) UpdateCrowding(L);
            }

            // ---- penalidades ----
            double congestion = 0;
            float worstUtil = 0f;
            for (int l = 0; l < L; l++)
            {
                if (_seats[l] <= 0) continue;
                float util = (float)(_onBoard[l] / _seats[l]);
                if (util > worstUtil) worstUtil = util;
                if (util > 1f) congestion += (util - 1f) * (util - 1f);
            }

            double stationLoad = 0;
            for (int s = 0; s < _n; s++)
            {
                float cap = Math.Max(1, _s.Capacity[s]);
                float util = (float)(_waiting[s] / cap);
                if (util > 1f) stationLoad += (util - 1f) * (util - 1f);
            }

            int unserved = 0;
            for (int s = 0; s < _n; s++) if (!_served[s]) unserved++;

            int crossingBudget = _s.Crossings + _s.Bridges;
            int over = Math.Max(0, crossingsUsed - crossingBudget);

            bd.TravelCost = travelCost;
            bd.UnreachableCost = unreachableCost;
            bd.CongestionCost = congestion * _cfg.CongestionWeight;
            bd.StationLoadCost = stationLoad * _cfg.StationLoadWeight;
            bd.TrackCost = totalTrack * _cfg.TrackLengthWeight;
            bd.CrossingCost = over * _cfg.CrossingOverBudget;
            bd.UnservedCost = unserved * _cfg.UnservedStationPenalty;

            bd.UnreachablePairs = unreachablePairs;
            bd.UnservedStations = unserved;
            bd.CrossingsUsed = crossingsUsed;
            bd.TrackLength = totalTrack;
            bd.WorstLineUtil = worstUtil;
            bd.AvgTravelTime = demandTotal > 0 ? (float)(weightedTime / demandTotal) : 0f;

            double total = bd.TravelCost + bd.UnreachableCost + bd.CongestionCost
                         + bd.StationLoadCost + bd.TrackCost + bd.CrossingCost + bd.UnservedCost;

            g.Fitness = total;
            g.Breakdown = bd;
            return total;
        }

        private void ResetGraph()
        {
            for (int i = 0; i < _nodeCap; i++) _head[i] = -1;
            _edgeCount = 0;
            for (int i = 0; i < _maxLines; i++) { _onBoard[i] = 0; _headwayWait[i] = 0f; }
            for (int i = 0; i < _n; i++) { _waiting[i] = 0; _served[i] = false; _linesAtStation[i].Clear(); }
        }

        /// <summary>
        /// Monta o grafo estacao x linha. A espera de embarque ja sai multiplicada
        /// pelo fator de lotacao do passe anterior (_crowd), que e 1 no primeiro passe.
        /// </summary>
        private void BuildGraph(Genome g, int L, float speed)
        {
            for (int l = 0; l < L; l++)
            {
                if (_cycle[l] <= 0f) continue;      // linha inexistente, curta ou sem trem

                var route = g.Routes[l];
                int m = route.Count;
                int trains = g.Locos[l];
                bool loop = g.Loops[l] && m >= 3;

                float headway = _cycle[l] / trains;
                _headwayWait[l] = headway * 0.5f * _crowd[l] + _cfg.BoardingPenalty;

                for (int k = 0; k < m; k++)
                {
                    int s = route[k];
                    _served[s] = true;
                    _linesAtStation[s].Add(l);

                    AddEdge(PlatformNode(s), RideNode(s, l), _headwayWait[l], -1);
                    AddEdge(RideNode(s, l), PlatformNode(s), _cfg.TransferPenalty, -1);
                }

                for (int k = 0; k + 1 < m; k++)
                {
                    int a = route[k], b = route[k + 1];
                    float w = _s.Dist[a][b] / speed + _cfg.DwellTime;
                    AddEdge(RideNode(a, l), RideNode(b, l), w, l);
                    AddEdge(RideNode(b, l), RideNode(a, l), w, l);
                }
                if (loop)
                {
                    int a = route[m - 1], b = route[0];
                    float w = _s.Dist[a][b] / speed + _cfg.DwellTime;
                    AddEdge(RideNode(a, l), RideNode(b, l), w, l);
                    AddEdge(RideNode(b, l), RideNode(a, l), w, l);
                }
            }
        }

        /// <summary>Uma Dijkstra por origem; credita fluxo e acumula custo de viagem.</summary>
        private void RouteDemand(ref double travelCost, ref double unreachableCost,
                                 ref double demandTotal, ref double weightedTime,
                                 ref int unreachablePairs)
        {
            for (int u = 0; u < _n; u++)
            {
                var rates = _s.DemandRate[u];

                if (!_served[u])
                {
                    // origem isolada: toda a demanda dela e perdida
                    for (int t = 0; t < _s.ShapeCount; t++)
                    {
                        double d = rates[t];
                        if (d <= 0) continue;
                        unreachableCost += d * _cfg.UnreachablePenalty;
                        demandTotal += d;
                        unreachablePairs++;
                    }
                    continue;
                }

                bool any = false;
                for (int t = 0; t < _s.ShapeCount; t++) if (rates[t] > 0) { any = true; break; }
                if (!any) continue;

                Dijkstra(PlatformNode(u));

                for (int t = 0; t < _s.ShapeCount; t++)
                {
                    double demand = rates[t];
                    if (demand <= 0) continue;

                    // o passageiro vai para a estacao MAIS PROXIMA da forma desejada
                    int best = -1;
                    float bestD = float.MaxValue;
                    for (int v = 0; v < _n; v++)
                    {
                        if (v == u || _s.ShapeOf[v] != t) continue;
                        float dv = _dist[PlatformNode(v)];
                        if (dv < bestD) { bestD = dv; best = v; }
                    }

                    demandTotal += demand;
                    if (best < 0 || bestD >= float.MaxValue * 0.5f)
                    {
                        unreachableCost += demand * _cfg.UnreachablePenalty;
                        unreachablePairs++;
                        continue;
                    }

                    travelCost += demand * bestD;
                    weightedTime += demand * bestD;
                    AccumulateFlow(PlatformNode(u), PlatformNode(best), demand);
                }
            }
        }

        /// <summary>
        /// Converte lotacao em espera extra: uma linha carregando o dobro dos assentos
        /// deixa, na media, um trem passar cheio - o passageiro espera dois headways.
        /// E o que faz um vagao a mais valer alguma coisa exatamente na linha que
        /// precisa dele, e nao em qualquer uma.
        /// </summary>
        private void UpdateCrowding(int L)
        {
            for (int l = 0; l < L; l++)
            {
                if (_seats[l] <= 0) { _crowd[l] = 1f; continue; }
                float util = (float)(_onBoard[l] / _seats[l]);
                if (util < 1f) util = 1f;
                if (util > _cfg.MaxCrowdingMultiplier) util = _cfg.MaxCrowdingMultiplier;
                _crowd[l] = util;
            }
        }

        private void AddEdge(int from, int to, float w, int line)
        {
            if (_edgeCount >= _edgeTo.Length) GrowEdges();
            _edgeTo[_edgeCount] = to;
            _edgeW[_edgeCount] = w;
            _edgeLine[_edgeCount] = line;
            _edgeNext[_edgeCount] = _head[from];
            _head[from] = _edgeCount;
            _edgeCount++;
        }

        private void GrowEdges()
        {
            int cap = _edgeTo.Length * 2;
            Array.Resize(ref _edgeTo, cap);
            Array.Resize(ref _edgeW, cap);
            Array.Resize(ref _edgeLine, cap);
            Array.Resize(ref _edgeNext, cap);
        }

        // ------------------------------------------------------------------
        // Dijkstra com heap binario indexado
        // ------------------------------------------------------------------
        private void Dijkstra(int src)
        {
            for (int i = 0; i < _nodeCap; i++)
            {
                _dist[i] = float.MaxValue;
                _done[i] = false;
                _prevNode[i] = -1;
                _prevEdge[i] = -1;
                _heapPos[i] = 0;
            }
            _heapSize = 0;
            _dist[src] = 0f;
            HeapPush(src);

            while (_heapSize > 0)
            {
                int u = HeapPop();
                if (_done[u]) continue;
                _done[u] = true;
                float du = _dist[u];

                for (int e = _head[u]; e != -1; e = _edgeNext[e])
                {
                    int v = _edgeTo[e];
                    if (_done[v]) continue;
                    float nd = du + _edgeW[e];
                    if (nd < _dist[v])
                    {
                        _dist[v] = nd;
                        _prevNode[v] = u;
                        _prevEdge[v] = e;
                        HeapPush(v);
                    }
                }
            }
        }

        private void HeapPush(int node)
        {
            if (_heapPos[node] > 0) { SiftUp(_heapPos[node]); return; }
            _heapSize++;
            _heap[_heapSize] = node;
            _heapPos[node] = _heapSize;
            SiftUp(_heapSize);
        }

        private int HeapPop()
        {
            int top = _heap[1];
            _heapPos[top] = 0;
            int last = _heap[_heapSize];
            _heapSize--;
            if (_heapSize > 0)
            {
                _heap[1] = last;
                _heapPos[last] = 1;
                SiftDown(1);
            }
            return top;
        }

        private void SiftUp(int i)
        {
            while (i > 1)
            {
                int p = i >> 1;
                if (_dist[_heap[p]] <= _dist[_heap[i]]) break;
                Swap(p, i);
                i = p;
            }
        }

        private void SiftDown(int i)
        {
            while (true)
            {
                int l = i << 1, r = l + 1, best = i;
                if (l <= _heapSize && _dist[_heap[l]] < _dist[_heap[best]]) best = l;
                if (r <= _heapSize && _dist[_heap[r]] < _dist[_heap[best]]) best = r;
                if (best == i) break;
                Swap(best, i);
                i = best;
            }
        }

        private void Swap(int a, int b)
        {
            int na = _heap[a], nb = _heap[b];
            _heap[a] = nb; _heap[b] = na;
            _heapPos[nb] = a; _heapPos[na] = b;
        }

        /// <summary>
        /// Anda de tras pra frente no caminho otimo e credita o fluxo:
        /// tempo a bordo vira "passageiros medios no trem" (Little),
        /// tempo de espera vira "passageiros medios na plataforma".
        /// </summary>
        private void AccumulateFlow(int srcNode, int dstNode, double demand)
        {
            int cur = dstNode;
            int guard = 0;
            while (cur != srcNode && cur >= 0 && guard++ < 512)
            {
                int e = _prevEdge[cur];
                if (e < 0) break;
                int line = _edgeLine[e];
                float w = _edgeW[e];
                int from = _prevNode[cur];

                if (line >= 0 && line < _maxLines)
                {
                    _onBoard[line] += demand * w;
                }
                else if (from < _n)
                {
                    // aresta de embarque: from e uma plataforma
                    _waiting[from] += demand * w;
                }
                cur = from;
            }
        }
    }
}
