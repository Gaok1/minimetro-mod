using System;
using System.Collections.Generic;
using System.Threading;

using MiniMetroGA.Core;
using UnityEngine;
using Random = System.Random;

namespace MiniMetroGA.Ga
{
    public enum GaState { Idle, Running, Done, Cancelled, Failed }

    /// <summary>
    /// Algoritmo genetico com selecao por torneio, elitismo, crossover em nivel de rota
    /// e um cardapio de mutacoes especificas do dominio. Roda numa thread propria e
    /// publica progresso de forma thread-safe para a UI ler todo frame.
    /// </summary>
    public class GaEngine
    {
        private readonly object _sync = new object();

        private Thread _thread;
        private volatile bool _cancel;

        public volatile GaState Status = GaState.Idle;
        public volatile int Generation;
        public volatile int TotalGenerations;
        public string Error { get; private set; }

        public double BestFitness { get; private set; } = double.MaxValue;
        public double AvgFitness { get; private set; }
        public double WorstFitness { get; private set; }
        public int StagnantFor { get; private set; }
        public long ElapsedMs { get; private set; }
        public int EvaluationsDone { get; private set; }

        public readonly List<float> HistoryBest = new List<float>(512);
        public readonly List<float> HistoryAvg = new List<float>(512);

        private Genome _best;
        private Snapshot _snapshot;
        private GaConfig _config;

        public Genome BestClone()
        {
            lock (_sync) { return _best?.Clone(); }
        }

        /// <summary>
        /// Checagem barata para a UI. OnGUI roda varias vezes por frame; usar
        /// BestClone() so para testar existencia clonaria o genoma inteiro em
        /// cada evento.
        /// </summary>
        public bool HasBest
        {
            get { lock (_sync) { return _best != null; } }
        }

        /// <summary>Copia o historico sob lock - a UI le isso todo frame.</summary>
        public void CopyHistory(List<float> best, List<float> avg)
        {
            best.Clear();
            avg.Clear();
            lock (_sync)
            {
                best.AddRange(HistoryBest);
                avg.AddRange(HistoryAvg);
            }
        }

        public Snapshot SnapshotRef
        {
            get { lock (_sync) { return _snapshot; } }
        }

        public GaConfig ConfigRef
        {
            get { lock (_sync) { return _config; } }
        }

        public bool IsRunning => Status == GaState.Running;

        public void Start(Snapshot snap, GaConfig cfg)
        {
            Stop();

            lock (_sync)
            {
                _snapshot = snap;
                _config = cfg;
                _best = null;
                HistoryBest.Clear();
                HistoryAvg.Clear();
            }

            BestFitness = double.MaxValue;
            AvgFitness = 0;
            Generation = 0;
            EvaluationsDone = 0;
            StagnantFor = 0;
            ElapsedMs = 0;
            TotalGenerations = cfg.Generations;
            Error = null;
            _cancel = false;
            Status = GaState.Running;

            _thread = new Thread(Run) { IsBackground = true, Name = "MiniMetroGA" };
            _thread.Start();
        }

        public void Stop()
        {
            _cancel = true;
            var t = _thread;
            if (t != null && t.IsAlive)
            {
                if (!t.Join(2000)) { try { t.Abort(); } catch (Exception) { } }
            }
            _thread = null;
            if (Status == GaState.Running) Status = GaState.Cancelled;
        }

        // ==================================================================
        private void Run()
        {
            var sw = System.Diagnostics.Stopwatch.StartNew();
            try
            {
                Snapshot snap;
                GaConfig cfg;
                lock (_sync) { snap = _snapshot; cfg = _config; }

                int seed = cfg.Seed != 0 ? cfg.Seed : Environment.TickCount;
                var rng = new Random(seed);

                int workers = Math.Max(1, Math.Min(Environment.ProcessorCount, 8));
                var evaluators = new Evaluator[workers];
                for (int i = 0; i < workers; i++) evaluators[i] = new Evaluator(snap, cfg);

                var pop = new List<Genome>(cfg.PopulationSize);
                var builder = new GenomeBuilder(snap, cfg);

                // semeia parte da populacao com a rede que o jogador ja construiu
                if (cfg.SeedFromCurrentNetwork && snap.CurrentRoutes.Count > 0)
                {
                    int seeds = Math.Max(1, cfg.PopulationSize / 10);
                    for (int i = 0; i < seeds; i++)
                    {
                        var g = builder.FromCurrent(rng);
                        if (i > 0) for (int m = 0; m < 3; m++) Mutator.Mutate(g, snap, cfg, rng);
                        g.Repair(snap, cfg, rng);
                        pop.Add(g);
                    }
                }
                while (pop.Count < cfg.PopulationSize)
                {
                    var g = builder.RandomConstructive(rng);
                    g.Repair(snap, cfg, rng);
                    pop.Add(g);
                }

                EvaluateAll(pop, evaluators, workers);
                EvaluationsDone += pop.Count;
                pop.Sort(CompareFitness);
                PublishGeneration(0, pop, sw);

                var next = new List<Genome>(cfg.PopulationSize);

                for (int gen = 1; gen <= cfg.Generations && !_cancel; gen++)
                {
                    next.Clear();

                    int elite = Mathf.Clamp(cfg.Elitism, 0, cfg.PopulationSize - 1);
                    for (int i = 0; i < elite; i++) next.Add(pop[i].Clone());

                    while (next.Count < cfg.PopulationSize)
                    {
                        var parentA = Tournament(pop, cfg, rng);
                        Genome child;

                        if (rng.NextDouble() < cfg.CrossoverRate)
                        {
                            var parentB = Tournament(pop, cfg, rng);
                            child = Crossover(parentA, parentB, rng);
                        }
                        else
                        {
                            child = parentA.Clone();
                        }

                        if (rng.NextDouble() < cfg.MutationRate)
                        {
                            int k = 1 + rng.Next(Math.Max(1, cfg.MutationsPerGenome));
                            for (int m = 0; m < k; m++) Mutator.Mutate(child, snap, cfg, rng);
                        }

                        child.Repair(snap, cfg, rng);
                        child.Fitness = double.MaxValue;
                        next.Add(child);
                    }

                    // reavalia so quem mudou (os elites ja tem fitness valido)
                    EvaluateAll(next, evaluators, workers);
                    EvaluationsDone += next.Count - elite;

                    var tmp = pop; pop = next; next = tmp;
                    pop.Sort(CompareFitness);

                    PublishGeneration(gen, pop, sw);

                    // estagnou: injeta sangue novo mantendo os elites
                    if (StagnantFor >= cfg.StagnationRestart && cfg.StagnationRestart > 0)
                    {
                        int keep = Math.Max(1, cfg.PopulationSize / 5);
                        for (int i = keep; i < pop.Count; i++)
                        {
                            var g = builder.RandomConstructive(rng);
                            g.Repair(snap, cfg, rng);
                            g.Fitness = double.MaxValue;
                            pop[i] = g;
                        }
                        EvaluateAll(pop, evaluators, workers);
                        pop.Sort(CompareFitness);
                        StagnantFor = 0;
                    }
                }

                Status = _cancel ? GaState.Cancelled : GaState.Done;
            }
            catch (ThreadAbortException)
            {
                Status = GaState.Cancelled;
            }
            catch (Exception e)
            {
                Error = e.ToString();
                Status = GaState.Failed;
                Log.Error("AG falhou: " + e);
            }
            finally
            {
                ElapsedMs = sw.ElapsedMilliseconds;
            }
        }

        /// <summary>
        /// Avalia a populacao em paralelo. System.Threading.Tasks.Parallel nao
        /// existe na BCL stripada do jogo, entao fatiamos a populacao a mao entre
        /// N threads. Cada worker tem o proprio Evaluator (que carrega buffers
        /// mutaveis), por isso nao ha estado compartilhado.
        /// </summary>
        private static void EvaluateAll(List<Genome> pop, Evaluator[] evaluators, int workers)
        {
            if (workers <= 1)
            {
                RunSlice(pop, evaluators[0], 0, 1);
                return;
            }

            var threads = new Thread[workers - 1];
            for (int w = 1; w < workers; w++)
            {
                int slice = w;
                var ev = evaluators[w];
                var t = new Thread(() => RunSlice(pop, ev, slice, workers)) { IsBackground = true };
                threads[w - 1] = t;
                t.Start();
            }

            // a thread do AG tambem trabalha, em vez de so esperar
            RunSlice(pop, evaluators[0], 0, workers);

            for (int i = 0; i < threads.Length; i++) threads[i].Join();
        }

        private static void RunSlice(List<Genome> pop, Evaluator ev, int start, int step)
        {
            for (int i = start; i < pop.Count; i += step)
                if (pop[i].Fitness == double.MaxValue) ev.Evaluate(pop[i]);
        }

        private void PublishGeneration(int gen, List<Genome> pop, System.Diagnostics.Stopwatch sw)
        {
            double best = pop[0].Fitness;
            double worst = pop[pop.Count - 1].Fitness;
            double sum = 0;
            int counted = 0;
            for (int i = 0; i < pop.Count; i++)
            {
                if (double.IsNaN(pop[i].Fitness) || pop[i].Fitness == double.MaxValue) continue;
                sum += pop[i].Fitness;
                counted++;
            }
            double avg = counted > 0 ? sum / counted : 0;

            bool improved = best < BestFitness - 1e-6;
            StagnantFor = improved ? 0 : StagnantFor + 1;

            lock (_sync)
            {
                if (improved || _best == null) _best = pop[0].Clone();
                HistoryBest.Add((float)best);
                HistoryAvg.Add((float)avg);
                if (HistoryBest.Count > 4000) { HistoryBest.RemoveAt(0); HistoryAvg.RemoveAt(0); }
            }

            if (improved) BestFitness = best;
            AvgFitness = avg;
            WorstFitness = worst;
            Generation = gen;
            ElapsedMs = sw.ElapsedMilliseconds;
        }

        private static int CompareFitness(Genome a, Genome b) => a.Fitness.CompareTo(b.Fitness);

        private static Genome Tournament(List<Genome> pop, GaConfig cfg, Random rng)
        {
            int k = Math.Max(2, cfg.TournamentSize);
            Genome best = null;
            for (int i = 0; i < k; i++)
            {
                var cand = pop[rng.Next(pop.Count)];
                if (best == null || cand.Fitness < best.Fitness) best = cand;
            }
            return best;
        }

        /// <summary>
        /// Crossover em nivel de rota: cada slot de linha do filho vem do pai A ou do B.
        /// Rotas sao unidades semanticas inteiras, entao trocar rotas preserva estrutura
        /// muito melhor do que qualquer crossover posicional sobre a lista achatada.
        /// </summary>
        private static Genome Crossover(Genome a, Genome b, Random rng)
        {
            var child = new Genome();
            int n = Math.Max(a.RouteCount, b.RouteCount);
            for (int i = 0; i < n; i++)
            {
                Genome src;
                if (i >= a.RouteCount) src = b;
                else if (i >= b.RouteCount) src = a;
                else src = rng.Next(2) == 0 ? a : b;

                if (i >= src.RouteCount) continue;
                child.Routes.Add(new List<int>(src.Routes[i]));
                child.Loops.Add(src.Loops[i]);
                child.Locos.Add(src.Locos[i]);
                child.Cars.Add(src.Cars[i]);
            }
            return child;
        }
    }
}
