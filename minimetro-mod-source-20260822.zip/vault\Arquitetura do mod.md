# Arquitetura do mod

## Fluxo geral

```
Doorstop (winhttp.dll)
   └─ Doorstop.Entrypoint.Start()          Entrypoint.cs
        └─ AssemblyLoad → sceneLoaded → ModBootstrap.EnsureHost()
             └─ GameObject "MiniMetroGA" + ModBehaviour
                  ├─ Update()  → GameHook.Refresh()  → GaWindow.Tick()
                  └─ OnGUI()   → GaWindow.Draw()

GaWindow (main thread)
   ├─ [Otimizar] → Snapshot.Capture(game)  ──► dados puros
   │                     └─ GaEngine.Start(snapshot, config)  ──► thread própria
   │                              ├─ GenomeBuilder   (população inicial)
   │                              ├─ Mutator         (operadores)
   │                              └─ Evaluator       (fitness, N threads)
   └─ [Aplicar]  → Applier.Apply(game, snapshot, melhorGenoma)
                        └─ dirige o LineBuilder do jogo
```

## Arquivos

| Arquivo | Papel |
|---|---|
| `Entrypoint.cs` | entrada do Doorstop, bootstrap, `Log`, `ModInfo` |
| `ModBehaviour.cs` | o único `MonoBehaviour`; `Update` e `OnGUI` |
| `Core/GameHook.cs` | acha `Game`, `City.stations`, linhas vivas — por reflexão |
| `Core/Snapshot.cs` | congela o estado do jogo em arrays puros |
| `Core/Applier.cs` | genoma → linhas reais, via `LineBuilder` |
| `Ga/GaConfig.cs` | todos os parâmetros (é o que a aba Parâmetros edita) |
| `Ga/Genome.cs` | encoding + `Repair` + `NormalizeFleet` |
| `Ga/GenomeBuilder.cs` | população inicial (clusters + vizinho mais próximo) |
| `Ga/Mutator.cs` | 10 operadores de mutação |
| `Ga/Evaluator.cs` | simulador surrogate + fitness |
| `Ga/GaEngine.cs` | laço do AG, threads, publicação de progresso |
| `UI/GaWindow.cs` | a janela IMGUI |
| `UI/Plot.cs` | gráfico de convergência e preview da rede, pixel a pixel |

## A regra de ouro das threads

O AG roda numa `Thread` própria. **A API do Unity e do jogo não é thread-safe.**

Por isso o [[Função de fitness|Evaluator]] só enxerga o `Snapshot`, que é
deliberadamente **só `float`, `int`, `bool` e arrays**. As referências vivas
(`Station`, `City`, `Game`) existem no snapshot mas são de uso exclusivo do
[[Aplicação da solução no jogo|Applier]], que roda na main thread.

Progresso e melhor indivíduo saem da thread do AG por `lock`:
`GaEngine.BestClone()` e `GaEngine.CopyHistory()`.

## Entrada do mouse

Enquanto o cursor está sobre o painel, o mod liga `game.IsLocked = true`.
Sem isso, clicar num botão da UI vira um traço de linha no mapa —
`Game.HandleSmartTouchBegan` retorna cedo quando `IsLocked`.

Ver também: [[Carregamento - Doorstop sem BepInEx]], [[Algoritmo Genético - design]]
