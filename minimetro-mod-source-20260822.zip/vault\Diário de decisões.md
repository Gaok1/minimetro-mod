# Diário de decisões

Registro cronológico do que foi tentado, o que quebrou e por quê.
Adicione entradas novas no topo.

---

## 2026-08-20 — Vagão sem gradiente: a unidade da demanda era fictícia

**Sintoma (relatado pelo jogador):** *"o otimizador atual tava jogando vagão em
qualquer trem parece, sem considerar onde a linha passava e a demanda"*.

Estava certo, e a causa não era o operador de mutação — era **aritmética de
unidades**.

A demanda era `SpawnWeight · ShapeProb · DemandScale`, com `DemandScale = 0.030`
escolhido no olho. `aBordo[l]` saía dessa unidade fictícia; `assentos` saía de
`(trens+vagões)·6`, em passageiros de verdade. As duas grandezas não eram
comparáveis. Na prática `util = aBordo/assentos` dava sempre ≪ 1, a penalidade de
lotação **nunca disparava**, e como a lotação era o *único* lugar onde vagão
aparecia no fitness, **vagão não tinha gradiente nenhum**. O AG distribuía vagão ao
acaso porque, para ele, todas as distribuições valiam exatamente o mesmo.

Detalhe incômodo: a própria nota [[Função de fitness]] já dizia *"se as penalidades
de lotação parecerem irrelevantes, mexa em `DemandScale`"*. A suspeita estava
escrita; faltou ir conferir.

**Correção em três camadas:**

1. **Unidade real.** A demanda passou a vir da tabela de spawn do jogo, em
   passageiros/segundo (`Clock.DayLength = 20 s` faz a conversão de dia para
   segundo). `DemandScale = 1.0` agora significa "o que o jogo faz". Capacidade e
   velocidade também deixaram de ser chute: saem de
   `City.Definition.TrainDefinition`.
2. **Realimentação de lotação.** Somar uma penalidade no fim não muda o
   *roteamento* — no grafo, linha lotada continuava tão atraente quanto linha
   vazia. Agora o roteamento roda duas vezes, e no segundo passe a espera de
   embarque é multiplicada por `aBordo/assentos`. Assim um vagão a mais reduz o
   tempo de viagem de gente de verdade, na linha certa.
3. **Heurísticas coerentes.** `DistributeFleet` e `ShiftCarriage` passaram a olhar
   demanda por assento em vez de sortear, e `NormalizeFleet` corta a unidade
   excedente de quem tem folga — não da última rota da lista, que era só a ordem em
   que o crossover deixou as coisas.

**Lição, irmã da anterior:** um número que não tem unidade física não tem como
estar certo nem errado — ele simplesmente não participa. O `Max(1, ...)` do bug
passado *escondia* uma inconsistência; a escala arbitrária deste aqui **desligava**
um termo inteiro do fitness sem nenhum sinal de erro. Vale a regra: toda grandeza
que vai ser comparada com outra precisa nascer na mesma unidade, e essa unidade
precisa estar escrita no código.

De quebra, ao revisar os pontos de orçamento achei um `s.LinesAvailable` que tinha
escapado da correção anterior, em `Mutator.AddOrDropRoute`.

---

## 2026-08-20 — Linhas nascendo sem trem: três bugs empilhados

**Sintoma (relatado pelo jogador):** o AG propunha redes em que uma das linhas
ficava sem nenhum trem. *"parece q ele n sabe que a linha tem Xs carros. ai uma
das linhas ele esgotou e n tem carro. mas isso n é uma solução valida"*.

Diagnóstico exato, e eram três problemas somados:

**1. O orçamento contava cada linha duas vezes.**
`Genome.NormalizeFleet` fazia `locoBudget = n + snap.Locomotives`, apoiado na
crença de que a linha nova ganha um trem de brinde. O decompilado desmente:
`Line.AddLink` chama `AssetDatabase.ConsumeAsset(assetType)` — o primeiro trem sai
do mesmo estoque, e só existe se houver um disponível. Com 3 linhas e 3 trens o AG
achava que tinha 6 e distribuía 2/2/2; na aplicação o estoque acabava na segunda
linha e a terceira nascia parada.

**2. O fitness era cego para o problema.**
`Evaluator` tinha `int trains = Math.Max(1, g.Locos[l])`. Esse `Max(1, ...)` fazia
uma linha com zero trens ser avaliada como se tivesse um — então a solução
impossível pontuava igual a uma possível, e o AG não tinha como aprender a evitá-la.
**Piso defensivo em número que representa um recurso escasso é bug esperando
acontecer**: ele não conserta o dado, só esconde a inconsistência de quem poderia
corrigi-la.

**3. O applier assumia o brinde** e pedia só `Locos[r] - 1` locomotivas.

**Correções:**

- `Snapshot.LineBudget = min(LinesAvailable, Locomotives)` — o teto real de linhas.
  Usado por `Repair`, `GenomeBuilder` e `Evaluator` no lugar de `LinesAvailable`.
- `NormalizeFleet`: orçamento = `Locomotives`, e corta rotas excedentes quando há
  mais rota do que trem (uma rota que nasceria parada não é uma rota).
- `Evaluator`: linha com `Locos[l] <= 0` é **ignorada** — não atende estação, não
  gera aresta, não consome trilho. O custo passa a refletir a verdade.
- `Applier`: lê `line.ActiveTrainCount` depois de construir e completa até
  `Locos[r]`, em vez de supor. Se ainda assim sobrar linha sem trem, conta em
  `LinesWithoutTrain` e a mensagem grita.
- UI: cartão de inventário mostra **Linhas operáveis** e avisa quando há mais
  linhas que trens.

Lição geral: o `Snapshot` tem que carregar o orçamento **já reduzido à forma que o
AG precisa**, não os números crus do jogo. Cada lugar que refazia a conta na mão
era uma chance de refazer diferente — e foram três.

---

## 2026-08-20 — A UI não aparecia: IMGUI de fábrica × CoreModule stripado

**Sintoma:** o painel não desenhava nada. O log do mod estava limpo — porque a
exceção acontecia dentro do `OnGUI`, e o `output_log.txt` do jogo tinha **6,4 MB**
dela:

```
MissingMethodException: Method not found: UnityEngine.Vector4 UnityEngine.Vector4.get_one()
  at MiniMetroGA.UI.GaWindow.DrawControl (Game game)
GUI Error: You are pushing more GUIClips than you are popping.
```

**A classe de falha nova.** Até aqui o problema era sempre "o jogo não tem a API".
Este é o inverso: a `IMGUIModule` que trouxemos de fábrica chama membros que o
stripping removeu do `CoreModule` **do jogo**. O compilador não pega, porque o
código quebrado não é o nosso.

**Resposta: auditar em vez de adivinhar.** Escrevemos `tools/StripAudit`
(`System.Reflection.Metadata`, ~100 linhas): lê todos os `MemberRef` de uma
assembly e confere contra o que existe nas assemblies que o jogo carrega.
Resultado, em um comando — exatamente 5 membros:

```
UnityEngine.Rect::set_center
UnityEngine.RectOffset::Remove
UnityEngine.TouchScreenKeyboard::get_isRequiredToForceOpen
UnityEngine.Vector4::get_one
UnityEngine.Vector4::op_Multiply
```

Um `grep` na IMGUI decompilada mostrou onde cada um mora, e o estrago foi maior
que o esperado: três estão dentro de `SliderHandler`, ou seja **slider, scrollbar
e `BeginScrollView` são todos inutilizáveis**. E `Vector4.one` está na sobrecarga
para a qual até `GUI.DrawTexture(rect, tex)` delega — o desenho de textura inteiro
estava fora.

**Decisão: widgets próprios.** `UI/Widgets.cs` e `UI/Theme.cs` implementam slider,
checkbox, abas, barras e rolagem na mão, sobre o subconjunto de IMGUI que sobrou
(`GUI.Label`, `GUI.Box`, `GUILayout.*`, `GUILayoutUtility.GetRect`,
`Event.current`). `Theme.Blit()` é o único caminho de desenho de textura, e chama
a sobrecarga longa de `GUI.DrawTexture`, que já recebe os `Vector4` prontos.

Efeito colateral bom: dava para trazer a `CoreModule` não-stripada e resolver tudo,
mas isso ampliaria a superfície de risco justamente na assembly mais central do
jogo. Widget próprio custou ~300 linhas e ficou mais bonito que o skin padrão.

Depois disso, duas armadilhas clássicas de IMGUI ainda derrubaram o layout
(`GetRect` mentindo no evento `Layout` e `hotControl` posicional). Ambas
documentadas em [[UI e controles]].

Verificação: `output_log.txt` caiu de 6,4 MB de exceções para 11 KB e zero
exceções, e o print confirmou o painel inteiro desenhado.

---

## 2026-08-20 — Loader próprio em vez de BepInEx + Harmony

**Tentativa 1: BepInEx 5.4.23.5 x86.**
Instalado, Doorstop rodou, mas o preloader estourou:

```
MissingMethodException: Method not found:
void System.Reflection.Module.GetPEKind(PortableExecutableKinds&, ImageFileMachine&)
```

`mscorlib` do jogo está stripado.

**Tentativa 2: corlib não-stripada** de `unity.bepinex.dev/corlibs/2022.3.62.zip`,
em `dll_search_path_override`. Pior: aquela `mscorlib` é de outro flavor e faz
P/Invoke em `System.Native`, inexistente aqui. Todo o IO do jogo quebrou
(`Interop.Sys`, `System.Console`, `File.Exists`). **Revertido.**

**Tentativa 3: só Harmony, sem BepInEx.** Também não:

```
TypeInitializationException: HarmonyLib.AccessTools
 ---> MissingMethodException: AmbiguousMatchException..ctor(string, Exception)
```

**Decisão: zero patching.** O que precisávamos era (a) um `MonoBehaviour` para
`OnGUI` e (b) a instância de `Game`. Ambos dão para conseguir sem patch:

- bootstrap via `SceneManager.sceneLoaded` (sobreviveu ao stripping)
- `Game` via reflexão em `Main.controller` → `GameController.game`

Resultado: o mod não depende de **nenhuma** biblioteca de terceiros.
Ver [[Carregamento - Doorstop sem BepInEx]].

---

## 2026-08-20 — IMGUI não-stripada, e só ela

O jogo não usa IMGUI, então o stripping arrancou quase tudo: `GUILayout` ficou com
`Width()` e `Height()`, e mais nada. Sem `Label`, `Button`, `Window`.

Alternativas consideradas:

1. **Hand-roll com o que sobrou** (`GUI.Label`, `GUI.Box`, `Event.current`) —
   viável, mas botões e sliders manuais, e feio.
2. **Usar Futile**, a UI do próprio jogo — garantido, mas muito mais código.
3. **Trazer a IMGUIModule não-stripada** — testado e funcionou.

Escolhida a 3. Só `UnityEngine.IMGUIModule.dll` + `netstandard.dll` em
`MiniMetroGA\lib`. O jogo carregou 3138 frames limpo, sem erro de assembly.

Lição: o override de assembly funciona **cirurgicamente**. Trocar o conjunto
inteiro (como o zip de `libraries/` faz) quebra tudo.

---

## 2026-08-20 — Compilar contra a BCL do jogo

Depois de perder tempo com `File.AppendAllText` falhando em silêncio, mudamos o
`.csproj` para `NoStdLib` + referências ao `mscorlib`/`System`/`System.Core`
**do jogo**. Na hora o compilador acusou `List<T>.GetRange` e o ctor de
`RectOffset`, que teriam virado bug de runtime.

Foi a mudança de maior retorno do projeto. Ver
[[Managed stripping - o problema central]].

---

## 2026-08-20 — Dirigir o LineBuilder em vez de montar links na mão

`Line.AddLink`/`AppendLink` são públicos e tentadores, mas replicar as regras do
jogo (túnel, terminador, travessia, orçamento) seria reimplementar o jogo.

`LineBuilder.HandleStationTouchBegan/Over/TouchEnded` é o mesmo caminho que o dedo
do jogador percorre — todas as validações vêm de graça, e uma jogada ilegal é
recusada em vez de corromper o estado. Ver [[Aplicação da solução no jogo]].

---

## 2026-08-20 — Fitness: grafo estação × linha

Alternativas para modelar baldeação:

1. grafo só de estações + contador de trocas de linha → não modela espera
2. simular o jogo de verdade → caro demais para 50k avaliações
3. **grafo (estação, linha) com arestas de embarque/desembarque** ← escolhida

A 3 embute o custo de baldeação nas arestas, então uma única Dijkstra por origem
já dá tempo de viagem *e* número de trocas, sem contabilidade extra.
Ver [[Função de fitness]].
