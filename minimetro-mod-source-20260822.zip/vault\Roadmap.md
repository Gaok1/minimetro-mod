# Roadmap

## Validação pendente

- [x] A UI desenha. Confirmado por screenshot em 2026-08-20, com
      `output_log.txt` em zero exceções. Ver [[Diário de decisões]].
- [x] Aplicar constrói linhas de verdade (o log registrou várias aplicações
      bem-sucedidas numa partida do jogador).
- [ ] Rodar o AG numa partida real e conferir que `Snapshot.Capture` lê estações,
      linhas e orçamento corretamente (a aba **Rede** mostra tudo).
- [ ] Conferir se a rede aplicada bate com o preview da aba **Rede**.
- [ ] Testar vagões numa cidade que já ofereceu vagão (`Vagões > 0` no cartão de
      inventário). Até agora só houve teste com `0 / 0`.
- [ ] Aplicar uma solução e confirmar que as linhas saem como no preview.
- [ ] Calibrar `TrainSpeed` e `DemandScale` contra o jogo — hoje são chutes
      razoáveis, não medições. Ver [[Função de fitness]].
- [ ] Testar em cidade com rio (Londres) para validar a detecção de travessia.

## Melhorias no algoritmo

- [ ] **Modo incremental**: hoje aplicar apaga tudo e reconstrói. Um modo que
      calcule o *diff* mínimo entre a rede atual e a alvo seria muito menos
      destrutivo — e permitiria modo automático sem piscar a tela.
- [ ] Otimização multiobjetivo (NSGA-II): expor a fronteira de Pareto entre tempo
      de viagem e lotação em vez de uma soma ponderada.
- [ ] Busca local (2-opt exaustivo no melhor indivíduo a cada N gerações) —
      memético costuma ganhar muito em roteamento.
- [ ] Levar em conta o *spawn* futuro de estações (`CityPlanner.StationSpawn`),
      não só o estado presente.
- [ ] Modelar interchanges (`AssetType.Interchange`) e a capacidade extra que dão.
- [ ] Ferries/`LinkType.Nautical` — hoje ignorados.

## Melhorias de UI

- [x] Aba de log dentro do painel.
- [x] Overlay de atalhos com feedback de tecla + progresso do AG (`UI/Hud.cs`).
- [x] Cartão de inventário lido direto do `AssetDatabase`.
- [ ] Overlay da solução **no mapa do jogo**, não só na miniatura do painel.
      Precisa converter `CityLayer` local → tela via Futile.
- [ ] Salvar/carregar presets de parâmetros em disco.
- [ ] Comparar A/B: fitness da rede atual vs. da proposta, lado a lado.
- [ ] Campo numérico para digitar parâmetro. Hoje só slider, porque
      `GUI.TextField` estoura neste build ([[APIs ausentes - lista viva]]) —
      precisaria de um editor de texto escrito na mão.

## Infra

- [x] Auditor de stripping (`tools/StripAudit`) — confere os `MemberRef` de uma
      assembly contra o que o jogo realmente carrega. Rodar sempre que entrar
      uma DLL nova em `lib/`.
- [ ] Teste offline do `Evaluator` (console app com snapshot sintético), para
      poder iterar no fitness sem abrir o jogo.
- [ ] Verificar o mod contra uma atualização do jogo: os nomes de campo usados por
      reflexão (`Main.controller`, `GameController.game`, `City.stations`) são o
      ponto frágil. Ver [[Engenharia reversa - API do Mini Metro]].
- [ ] Outros algoritmos além do AG (o pedido original diz "AG por enquanto"):
      simulated annealing e ACO reusariam o mesmo `Evaluator` e a mesma UI.
