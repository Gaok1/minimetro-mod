using System;
using System.Collections.Generic;
using MiniMetroGA.Core;

namespace MiniMetroGA.Ga
{
    /// <summary>
    /// Cardapio de mutacoes especificas do dominio. Mutacao generica (flipar um gene
    /// aleatorio) nao funciona bem aqui: as boas jogadas do Mini Metro sao
    /// "enfia essa estacao no meio dessa linha", "inverte esse trecho", "manda um trem
    /// da linha vazia pra linha lotada". Cada operador abaixo e uma dessas jogadas.
    /// </summary>
    public static class Mutator
    {
        private const int OperatorCount = 10;

        public static void Mutate(Genome g, Snapshot s, GaConfig cfg, Random rng)
        {
            if (g.RouteCount == 0) return;

            switch (rng.Next(OperatorCount))
            {
                case 0: InsertBestPosition(g, s, cfg, rng); break;
                case 1: InsertRandom(g, s, cfg, rng); break;
                case 2: RemoveStation(g, cfg, rng); break;
                case 3: SwapWithinRoute(g, rng); break;
                case 4: TwoOpt(g, rng); break;
                case 5: MoveBetweenRoutes(g, cfg, rng); break;
                case 6: ToggleLoop(g, cfg, rng); break;
                case 7: ShiftLocomotive(g, s, rng); break;
                case 8: ShiftCarriage(g, s, rng); break;
                case 9: AddOrDropRoute(g, s, cfg, rng); break;
            }
        }

        /// <summary>Insere uma estacao fora da linha na posicao de menor custo adicional.</summary>
        private static void InsertBestPosition(Genome g, Snapshot s, GaConfig cfg, Random rng)
        {
            int r = rng.Next(g.RouteCount);
            var route = g.Routes[r];
            if (route.Count >= cfg.MaxStationsPerLine) return;

            int station = PickStationNotIn(route, s, rng);
            if (station < 0) return;

            int bestPos = 0;
            float bestDelta = float.MaxValue;
            for (int p = 0; p <= route.Count; p++)
            {
                float delta;
                if (p == 0) delta = s.Dist[station][route[0]];
                else if (p == route.Count) delta = s.Dist[route[route.Count - 1]][station];
                else delta = s.Dist[route[p - 1]][station] + s.Dist[station][route[p]]
                           - s.Dist[route[p - 1]][route[p]];
                if (delta < bestDelta) { bestDelta = delta; bestPos = p; }
            }
            route.Insert(bestPos, station);
        }

        private static void InsertRandom(Genome g, Snapshot s, GaConfig cfg, Random rng)
        {
            int r = rng.Next(g.RouteCount);
            var route = g.Routes[r];
            if (route.Count >= cfg.MaxStationsPerLine) return;
            int station = PickStationNotIn(route, s, rng);
            if (station < 0) return;
            route.Insert(rng.Next(route.Count + 1), station);
        }

        private static void RemoveStation(Genome g, GaConfig cfg, Random rng)
        {
            int r = rng.Next(g.RouteCount);
            var route = g.Routes[r];
            if (route.Count <= Math.Max(2, cfg.MinStationsPerLine)) return;
            route.RemoveAt(rng.Next(route.Count));
        }

        private static void SwapWithinRoute(Genome g, Random rng)
        {
            int r = rng.Next(g.RouteCount);
            var route = g.Routes[r];
            if (route.Count < 2) return;
            int i = rng.Next(route.Count), j = rng.Next(route.Count);
            if (i == j) return;
            int t = route[i]; route[i] = route[j]; route[j] = t;
        }

        /// <summary>Inverte um trecho da rota - o classico 2-opt de TSP.</summary>
        private static void TwoOpt(Genome g, Random rng)
        {
            int r = rng.Next(g.RouteCount);
            var route = g.Routes[r];
            if (route.Count < 4) return;
            int i = rng.Next(route.Count - 1);
            int j = i + 1 + rng.Next(route.Count - i - 1);
            while (i < j)
            {
                int t = route[i]; route[i] = route[j]; route[j] = t;
                i++; j--;
            }
        }

        private static void MoveBetweenRoutes(Genome g, GaConfig cfg, Random rng)
        {
            if (g.RouteCount < 2) return;
            int from = rng.Next(g.RouteCount);
            int to = rng.Next(g.RouteCount);
            if (from == to) return;

            var src = g.Routes[from];
            var dst = g.Routes[to];
            if (src.Count <= Math.Max(2, cfg.MinStationsPerLine)) return;
            if (dst.Count >= cfg.MaxStationsPerLine) return;

            int idx = rng.Next(src.Count);
            int station = src[idx];
            if (dst.Contains(station)) return;
            src.RemoveAt(idx);
            dst.Insert(rng.Next(dst.Count + 1), station);
        }

        private static void ToggleLoop(Genome g, GaConfig cfg, Random rng)
        {
            if (!cfg.AllowLoops) return;
            int r = rng.Next(g.RouteCount);
            if (g.Routes[r].Count < 3) return;
            g.Loops[r] = !g.Loops[r];
        }

        /// <summary>
        /// Tira uma locomotiva da linha mais folgada e poe na mais apertada.
        /// Metade das vezes sorteia os dois lados, para nao virar uma heuristica
        /// gulosa disfarcada de mutacao - o AG ainda precisa explorar.
        /// </summary>
        private static void ShiftLocomotive(Genome g, Snapshot s, Random rng)
        {
            if (g.RouteCount < 2) return;

            bool greedy = rng.Next(2) == 0;
            int from = greedy ? SlackestRoute(g, s, cars: false) : rng.Next(g.RouteCount);
            int to = greedy ? TightestRoute(g, s, cars: false) : rng.Next(g.RouteCount);
            if (from < 0 || to < 0 || from == to) return;
            if (g.Locos[from] <= 1) return;
            if (g.Locos[to] >= s.MaxLocosFor(to)) return;
            g.Locos[from]--;
            g.Locos[to]++;
        }

        private static void ShiftCarriage(Genome g, Snapshot s, Random rng)
        {
            if (g.RouteCount < 2) return;

            bool greedy = rng.Next(2) == 0;
            int from = greedy ? SlackestRoute(g, s, cars: true) : rng.Next(g.RouteCount);
            int to = greedy ? TightestRoute(g, s, cars: true) : rng.Next(g.RouteCount);
            if (from < 0 || to < 0 || from == to) return;
            if (g.Cars[from] <= 0) return;
            if (g.Cars[to] >= g.Locos[to] * s.MaxCarsPerLoco) return;
            g.Cars[from]--;
            g.Cars[to]++;
        }

        /// <summary>Menor demanda por assento entre as rotas que ainda podem ceder uma unidade.</summary>
        private static int SlackestRoute(Genome g, Snapshot s, bool cars)
        {
            int best = -1;
            double bestScore = double.MaxValue;
            for (int i = 0; i < g.RouteCount; i++)
            {
                if (cars) { if (g.Cars[i] <= 0) continue; }
                else if (g.Locos[i] <= 1) continue;
                double score = DemandPerSeat(g, s, i);
                if (score < bestScore) { bestScore = score; best = i; }
            }
            return best;
        }

        /// <summary>Maior demanda por assento entre as rotas que ainda cabem mais uma unidade.</summary>
        private static int TightestRoute(Genome g, Snapshot s, bool cars)
        {
            int best = -1;
            double bestScore = -1.0;
            for (int i = 0; i < g.RouteCount; i++)
            {
                if (cars) { if (g.Cars[i] >= g.Locos[i] * s.MaxCarsPerLoco) continue; }
                else if (g.Locos[i] >= s.MaxLocosFor(i)) continue;
                double score = DemandPerSeat(g, s, i);
                if (score > bestScore) { bestScore = score; best = i; }
            }
            return best;
        }

        private static double DemandPerSeat(Genome g, Snapshot s, int route)
        {
            int seats = (g.Locos[route] + g.Cars[route]) * Math.Max(1, s.RailcarCapacity);
            return g.RouteDemand(s, route) / Math.Max(1, seats);
        }

        /// <summary>
        /// Muda o numero de linhas: ou quebra a maior rota em duas, ou funde a menor
        /// na vizinha. E o operador que deixa o AG decidir quantas linhas realmente usar.
        /// </summary>
        private static void AddOrDropRoute(Genome g, Snapshot s, GaConfig cfg, Random rng)
        {
            // LineBudget, nao LinesAvailable: linha sem trem para botar nela nao e
            // linha. Este ponto tinha escapado da correcao do orcamento de frota.
            int maxLines = cfg.MaxLinesOverride > 0
                ? Math.Min(cfg.MaxLinesOverride, s.LineBudget)
                : s.LineBudget;

            bool split = rng.Next(2) == 0;

            if (split && g.RouteCount < maxLines)
            {
                int biggest = 0;
                for (int i = 1; i < g.RouteCount; i++)
                    if (g.Routes[i].Count > g.Routes[biggest].Count) biggest = i;

                var route = g.Routes[biggest];
                if (route.Count < 2 * Math.Max(2, cfg.MinStationsPerLine)) return;

                int cut = route.Count / 2;
                // List<T>.GetRange foi removido pelo stripping do jogo
                var tail = new List<int>(route.Count - cut);
                for (int i = cut; i < route.Count; i++) tail.Add(route[i]);
                route.RemoveRange(cut, route.Count - cut);
                g.Routes.Add(tail);
                g.Loops.Add(false);
                g.Locos.Add(1);
                g.Cars.Add(0);
            }
            else if (!split && g.RouteCount > 1)
            {
                int smallest = 0;
                for (int i = 1; i < g.RouteCount; i++)
                    if (g.Routes[i].Count < g.Routes[smallest].Count) smallest = i;

                int target = rng.Next(g.RouteCount);
                if (target == smallest) target = (smallest + 1) % g.RouteCount;

                foreach (int st in g.Routes[smallest])
                    if (!g.Routes[target].Contains(st) && g.Routes[target].Count < cfg.MaxStationsPerLine)
                        g.Routes[target].Add(st);

                g.Locos[target] = Math.Min(s.MaxLocosFor(target), g.Locos[target] + g.Locos[smallest]);
                g.Cars[target] += g.Cars[smallest];

                g.Routes.RemoveAt(smallest);
                g.Loops.RemoveAt(smallest);
                g.Locos.RemoveAt(smallest);
                g.Cars.RemoveAt(smallest);
            }
        }

        private static int PickStationNotIn(List<int> route, Snapshot s, Random rng)
        {
            for (int attempt = 0; attempt < 12; attempt++)
            {
                int cand = rng.Next(s.N);
                if (!route.Contains(cand)) return cand;
            }
            return -1;
        }
    }
}
