using System;
using System.Collections.Generic;
using System.Text;
using MiniMetroGA.Ga;
using UnityEngine;

namespace MiniMetroGA.Core
{
    /// <summary>
    /// Traduz o melhor genoma em acoes reais dentro do jogo.
    ///
    /// Ponto chave: nao mexemos nas estruturas internas na mao. Dirigimos o
    /// <see cref="LineBuilder"/> exatamente como o dedo do jogador faria
    /// (TouchBegan na primeira estacao, TouchOver em cada seguinte, TouchEnded).
    /// Assim o jogo aplica sozinho todas as regras dele: tuneis, custo de linha,
    /// travessias, terminadores, validacoes. Se a jogada e ilegal, o jogo recusa,
    /// e nao ficamos com um estado corrompido.
    ///
    /// Roda SEMPRE na main thread.
    /// </summary>
    public static class Applier
    {
        public struct Result
        {
            public int LinesBuilt;
            public int LinesFailed;
            public int LocomotivesPlaced;
            public int CarriagesPlaced;
            public int LocomotivesWanted;
            public int CarriagesWanted;
            public int LinesWithoutTrain;
            public string Message;
            public bool Ok;
        }

        public static Result Apply(Game game, Snapshot snap, Genome genome, bool clearExisting = true)
        {
            var res = new Result();
            if (game == null || snap == null || genome == null)
            {
                res.Message = "Nada para aplicar.";
                return res;
            }

            var city = game.City;
            if (city == null) { res.Message = "Cidade indisponivel."; return res; }

            bool wasPaused = game.IsPaused;
            game.IsPaused = true;

            try
            {
                CancelPendingEdit(game);

                if (clearExisting) RemoveAllLines(city);

                for (int r = 0; r < genome.RouteCount; r++)
                {
                    var route = genome.Routes[r];
                    if (route.Count < 2) continue;

                    var built = BuildLine(game, snap, route, genome.Loops[r]);
                    if (built == null) { res.LinesFailed++; continue; }
                    res.LinesBuilt++;

                    // Quantos trens a linha JA tem. O jogo costuma colocar um sozinho
                    // ao abrir a linha, mas so se houver um disponivel no estoque -
                    // assumir que sempre vem era o que deixava linha nascendo parada.
                    int have = TrainCountOf(built);
                    int missing = Math.Max(0, genome.Locos[r] - have);
                    res.LocomotivesWanted += missing;
                    for (int i = 0; i < missing; i++)
                    {
                        if (TryApplyAsset(built, PreferredLocomotive(game))) res.LocomotivesPlaced++;
                        else break;
                    }

                    if (TrainCountOf(built) <= 0)
                    {
                        res.LinesWithoutTrain++;
                        Log.Warn("Linha " + (r + 1) + " ficou sem trem: estoque de locomotivas acabou.");
                    }
                    res.CarriagesWanted += genome.Cars[r];
                    for (int i = 0; i < genome.Cars[r]; i++)
                    {
                        if (TryApplyAsset(built, AssetType.Carriage)) res.CarriagesPlaced++;
                        else break;
                    }
                }

                res.Ok = res.LinesBuilt > 0 && res.LinesWithoutTrain == 0;
                res.Message = Describe(res, snap);
            }
            catch (Exception e)
            {
                res.Message = "Erro ao aplicar: " + e.Message;
                Log.Error("Applier: " + e);
            }
            finally
            {
                game.IsPaused = wasPaused;
            }

            return res;
        }

        /// <summary>
        /// Mensagem que diz o que aconteceu E por que faltou. "0 vagoes" sozinho
        /// parece defeito do mod; "0 vagoes (nenhum no inventario)" e informacao.
        /// </summary>
        private static string Describe(Result res, Snapshot snap)
        {
            var sb = new StringBuilder();
            sb.AppendFormat("{0} linha(s)", res.LinesBuilt);
            if (res.LinesFailed > 0) sb.AppendFormat(", {0} recusada(s) pelo jogo", res.LinesFailed);

            sb.AppendFormat(" | trens +{0}/{1}", res.LocomotivesPlaced, res.LocomotivesWanted);
            sb.AppendFormat(" | vagoes +{0}/{1}", res.CarriagesPlaced, res.CarriagesWanted);

            if (res.LinesWithoutTrain > 0)
            {
                sb.AppendFormat(" | ATENCAO: {0} linha(s) SEM TREM", res.LinesWithoutTrain);
                return sb.ToString();
            }

            if (res.CarriagesWanted == 0)
            {
                sb.Append(snap.CarsTotal == 0
                    ? " (a cidade ainda nao deu nenhum vagao)"
                    : " (o AG preferiu nao usar vagao)");
            }
            else if (res.CarriagesPlaced < res.CarriagesWanted)
            {
                sb.Append(" (inventario acabou antes)");
            }

            return sb.ToString();
        }

        private static AssetType PreferredLocomotive(Game game)
        {
            try
            {
                var t = game.AssetDatabase.AvailableLocomotiveAsset;
                if (t == AssetType.Locomotive || t == AssetType.Shinkansen || t == AssetType.Tram) return t;
            }
            catch (Exception) { }
            return AssetType.Locomotive;
        }

        private static int TrainCountOf(Line line)
        {
            try { return line.ActiveTrainCount; } catch (Exception) { return 0; }
        }

        private static bool TryApplyAsset(Line line, AssetType type)
        {
            try { return line.ApplyAsset(type, null, LineDirection.FORWARDS, null, true, false, false); }
            catch (Exception) { return false; }
        }

        private static void CancelPendingEdit(Game game)
        {
            try
            {
                var lb = game.LineBuilder;
                if (lb != null && lb.IsBuilding) lb.HandleTouchCanceled();
            }
            catch (Exception) { }
        }

        private static void RemoveAllLines(City city)
        {
            var lines = GameHook.GetLiveLines(city);
            for (int i = lines.Count - 1; i >= 0; i--)
            {
                try { lines[i].Remove(); }
                catch (Exception e) { Log.Warn("Falha ao remover linha: " + e.Message); }
            }
        }

        /// <summary>
        /// Constroi uma linha simulando o gesto de arrastar por cima das estacoes.
        /// Devolve a Line criada, ou null se o jogo recusou a jogada.
        /// </summary>
        private static Line BuildLine(Game game, Snapshot snap, List<int> route, bool loop)
        {
            var lb = game.LineBuilder;
            if (lb == null) return null;
            if (lb.IsBuilding) lb.HandleTouchCanceled();

            var first = snap.StationRefs[route[0]];
            if (first == null) return null;

            lb.HandleStationTouchBegan(first, ToGlobal(game, first.Position));
            if (!lb.IsBuilding)
            {
                if (Log.Verbose)
                    Log.Warn("LineBuilder recusou iniciar em " + route[0] + " (sem linha livre?)");
                return null;
            }

            var line = lb.Line;

            for (int k = 1; k < route.Count; k++)
            {
                var st = snap.StationRefs[route[k]];
                if (st == null) continue;
                lb.HandleTouchMove(ToGlobal(game, st.Position));
                lb.HandleStationTouchOver(st);
                if (!lb.IsBuilding) break; // o jogo fechou a linha sozinho
            }

            if (loop && lb.IsBuilding && route.Count >= 3)
            {
                lb.HandleTouchMove(ToGlobal(game, first.Position));
                lb.HandleStationTouchOver(first);
            }

            if (lb.IsBuilding) lb.HandleTouchEnded();

            return line != null && !line.IsMothballed && line.Index >= 0 ? line : null;
        }

        /// <summary>
        /// Station.Position esta no espaco local da CityLayer, mas o LineBuilder
        /// espera coordenadas globais (ele mesmo converte de volta).
        /// </summary>
        private static Vector2 ToGlobal(Game game, Vector2 localPos)
        {
            try { return game.City.CityLayer.LocalToGlobal(localPos); }
            catch (Exception) { return localPos; }
        }
    }
}
