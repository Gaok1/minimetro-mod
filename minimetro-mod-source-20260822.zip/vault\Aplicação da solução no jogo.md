# Aplicação da solução no jogo

Traduzir o melhor genoma em linhas de verdade é onde um mod normalmente quebra o
save. A decisão que evita isso:

> [!important] Não mexemos nas estruturas internas na mão.
> Dirigimos o `LineBuilder` do jogo exatamente como o dedo do jogador faria.

## O gesto

`LineBuilder` é o que a UI de toque usa. A sequência é:

```csharp
lb.HandleStationTouchBegan(primeira, ToGlobal(primeira.Position));
foreach (var st in resto) {
    lb.HandleTouchMove(ToGlobal(st.Position));
    lb.HandleStationTouchOver(st);
}
if (circular) lb.HandleStationTouchOver(primeira);
lb.HandleTouchEnded();
```

Por que isso é seguro: o jogo aplica **as regras dele** em cada passo — túneis,
custo de linha, travessias de rio, terminadores, validações. Se a jogada for
ilegal, o jogo recusa e o mod só registra a falha. Nunca ficamos com estado
corrompido.

Detalhes que custaram leitura do decompilado:

- `HandleStationTouchBegan` espera **coordenadas globais**; `Station.Position` é
  local da `CityLayer`. Daí o `city.CityLayer.LocalToGlobal(...)`.
- `HandleStationTouchOver` retorna cedo se `focus == station`, então chamadas
  sequenciais funcionam sem gambiarra.
- Ele pode **fechar a linha sozinho** (ao voltar na primeira estação). Por isso o
  laço checa `lb.IsBuilding` a cada passo.

## Ordem das operações

1. Pausa o jogo (guarda o estado anterior para restaurar no `finally`).
2. Cancela qualquer edição pendente (`HandleTouchCanceled`).
3. **Remove todas as linhas** (`Line.Remove()`, que devolve o asset de linha).
4. Constrói cada rota do genoma.
5. Adiciona frota: `Line.ApplyAsset(Locomotive/Carriage)`.
6. Restaura o estado de pausa.

> [!warning] Aplicar apaga **todas** as linhas atuais e reconstrói do zero.
> É o comportamento pretendido (o genoma descreve a rede inteira), mas é
> destrutivo. Um modo incremental está no [[Roadmap]].

## Frota

`Line.ApplyAsset` já checa disponibilidade e consome do `AssetDatabase`, e devolve
`false` quando não dá. O `Applier` só chama em laço e para no primeiro `false`.

> [!danger] O trem da linha nova **não é grátis** — e essa era a versão errada
> desta nota. `Line.AddLink`, ao abrir a linha, chama
> `AssetDatabase.ConsumeAsset(assetType)`: o primeiro trem sai do **mesmo
> estoque**. E só acontece se houver um disponível; se não houver, a linha nasce
> com `isWaitingForLocomotive = true`, ou seja, **parada**.

Consequência prática: o teto de linhas é `min(linhas, locomotivas)`, não o número
de linhas. Ver `Snapshot.LineBudget`.

O `Applier` **não assume nada**: depois de construir, lê `line.ActiveTrainCount` e
completa até `Locos[r]`. Se mesmo assim a linha ficar com zero, ele conta em
`Result.LinesWithoutTrain` e a mensagem final grita `ATENCAO: N linha(s) SEM TREM`.

O tipo de locomotiva preferido sai de `AssetDatabase.AvailableLocomotiveAsset`
(pode ser `Shinkansen` ou `Tram` dependendo da cidade).

Ver também: [[Engenharia reversa - API do Mini Metro]]
