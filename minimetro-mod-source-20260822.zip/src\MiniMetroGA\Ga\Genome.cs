using System;
using System.Collections.Generic;
using System.Text;
using MiniMetroGA.Core;

namespace MiniMetroGA.Ga
{
    /// <summary>
    /// Um individuo = uma rede de metro inteira.
    ///
    /// Encoding: uma lista de rotas, cada rota e uma sequencia ordenada de indices
    /// de estacao (sem repeticao dentro da mesma rota). Uma estacao pode aparecer em
    /// varias rotas - e assim que baldeacoes surgem. Alem disso cada rota carrega
    /// quantas locomotivas e vagoes recebe, porque distribuir material rodante e
    /// metade do problema no Mini Metro.
    /// </summary>
    public class Genome
    {
        public List<List<int>> Routes = new List<List<int>>();
        public List<bool> Loops = new List<bool>();
        public List<int> Locos = new List<int>();
        public List<int> Cars = new List<int>();

        public double Fitness = double.MaxValue;
        public EvalBreakdown Breakdown;

        public int RouteCount => Routes.Count;

        public Genome Clone()
        {
            var g = new Genome
            {
                Routes = new List<List<int>>(Routes.Count),
                Loops = new List<bool>(Loops),
                Locos = new List<int>(Locos),
                Cars = new List<int>(Cars),
                Fitness = Fitness,
                Breakdown = Breakdown
            };
            for (int i = 0; i < Routes.Count; i++) g.Routes.Add(new List<int>(Routes[i]));
            return g;
        }

        /// <summary>
        /// Garante que o genoma e legal: sem duplicatas na rota, sem rota curta demais,
        /// sem passar do numero de linhas, e com o material rodante dentro do orcamento.
        /// Chamado depois de todo crossover/mutacao.
        /// </summary>
        public void Repair(Snapshot snap, GaConfig cfg, Random rng)
        {
            // LineBudget, nao LinesAvailable: nao adianta ter linha sobrando se nao
            // ha trem para botar nela. Ver Snapshot.LineBudget.
            int maxLines = cfg.MaxLinesOverride > 0
                ? Math.Min(cfg.MaxLinesOverride, snap.LineBudget)
                : snap.LineBudget;

            for (int r = Routes.Count - 1; r >= 0; r--)
            {
                var route = Routes[r];

                // tira duplicatas e indices fora do range
                var seen = new HashSet<int>();
                for (int i = route.Count - 1; i >= 0; i--)
                {
                    int v = route[i];
                    if (v < 0 || v >= snap.N || !seen.Add(v)) route.RemoveAt(i);
                }

                if (route.Count > cfg.MaxStationsPerLine)
                    route.RemoveRange(cfg.MaxStationsPerLine, route.Count - cfg.MaxStationsPerLine);

                if (route.Count < Math.Max(2, cfg.MinStationsPerLine))
                {
                    Routes.RemoveAt(r);
                    Loops.RemoveAt(r);
                    Locos.RemoveAt(r);
                    Cars.RemoveAt(r);
                }
            }

            while (Routes.Count > maxLines)
            {
                int worst = Routes.Count - 1;
                Routes.RemoveAt(worst);
                Loops.RemoveAt(worst);
                Locos.RemoveAt(worst);
                Cars.RemoveAt(worst);
            }

            if (Routes.Count == 0)
            {
                // genoma degenerado: recria uma rota minima
                var route = new List<int>();
                int a = rng.Next(snap.N);
                int b = rng.Next(snap.N);
                if (b == a) b = (a + 1) % snap.N;
                route.Add(a); route.Add(b);
                Routes.Add(route); Loops.Add(false); Locos.Add(1); Cars.Add(0);
            }

            if (!cfg.AllowLoops)
                for (int i = 0; i < Loops.Count; i++) Loops[i] = false;

            // loop so faz sentido com 3+ estacoes
            for (int i = 0; i < Loops.Count; i++)
                if (Routes[i].Count < 3) Loops[i] = false;

            NormalizeFleet(snap);
        }

        /// <summary>
        /// Cada linha precisa de pelo menos 1 locomotiva - uma linha sem trem nao
        /// transporta ninguem, entao nao e uma solucao valida, e sim uma rota morta.
        ///
        /// O orcamento e o total de locomotivas da cidade, e mais nada. O trem que
        /// aparece sozinho quando voce desenha uma linha nova sai desse mesmo
        /// estoque (Line.AddLink chama AssetDatabase.ConsumeAsset), entao somar um
        /// "brinde por linha" contava cada linha duas vezes - era isso que deixava
        /// a ultima linha da rede sem nenhum trem.
        /// </summary>
        public void NormalizeFleet(Snapshot snap)
        {
            int locoBudget = Math.Max(1, snap.Locomotives);

            // mais rotas do que trens = rota que nasceria parada; corta as ultimas
            while (Routes.Count > locoBudget)
            {
                int last = Routes.Count - 1;
                Routes.RemoveAt(last);
                if (Loops.Count > last) Loops.RemoveAt(last);
                if (Locos.Count > last) Locos.RemoveAt(last);
                if (Cars.Count > last) Cars.RemoveAt(last);
            }

            int n = Routes.Count;
            while (Locos.Count < n) Locos.Add(1);
            while (Cars.Count < n) Cars.Add(0);
            while (Loops.Count < n) Loops.Add(false);

            for (int i = 0; i < n; i++)
                Locos[i] = Clamp(Locos[i], 1, snap.MaxLocosFor(i));

            // Quando estoura o orcamento, corta de quem tem menos demanda por assento
            // - nao da ultima linha da lista, que era so a ordem em que o crossover
            // deixou as rotas. Cortar pela ordem devolvia genomas cuja frota nao tinha
            // relacao nenhuma com por onde as linhas passam.
            int used = 0;
            for (int i = 0; i < n; i++) used += Locos[i];
            while (used > locoBudget)
            {
                int victim = LeastDeserving(snap, alsoNeedsCars: false);
                if (victim < 0) break;              // todas ja em 1: nao ha o que cortar
                Locos[victim]--;
                used--;
            }

            int carBudget = Math.Max(0, snap.Carriages);
            for (int i = 0; i < n; i++)
                Cars[i] = Clamp(Cars[i], 0, Locos[i] * snap.MaxCarsPerLoco);
            used = 0;
            for (int i = 0; i < n; i++) used += Cars[i];
            while (used > carBudget)
            {
                int victim = LeastDeserving(snap, alsoNeedsCars: true);
                if (victim < 0) break;
                Cars[victim]--;
                used--;
            }
        }

        /// <summary>
        /// A linha com menor demanda por assento - a que menos sente perder uma unidade.
        /// Devolve -1 se ninguem pode ceder (toda linha ja no minimo).
        /// </summary>
        private int LeastDeserving(Snapshot snap, bool alsoNeedsCars)
        {
            int best = -1;
            double bestScore = double.MaxValue;
            for (int i = 0; i < Routes.Count; i++)
            {
                if (alsoNeedsCars) { if (Cars[i] <= 0) continue; }
                else if (Locos[i] <= 1) continue;

                int seats = (Locos[i] + Cars[i]) * Math.Max(1, snap.RailcarCapacity);
                double score = RouteDemand(snap, i) / Math.Max(1, seats);
                if (score < bestScore) { bestScore = score; best = i; }
            }
            return best;
        }

        /// <summary>Demanda somada das estacoes que a rota atende, em passageiros/segundo.</summary>
        public double RouteDemand(Snapshot snap, int route)
        {
            if (snap.StationDemand == null) return 0.0;
            var r = Routes[route];
            double sum = 0.0;
            for (int k = 0; k < r.Count; k++)
            {
                int st = r[k];
                if (st >= 0 && st < snap.StationDemand.Length) sum += snap.StationDemand[st];
            }
            return sum;
        }

        private static int Clamp(int v, int lo, int hi) => v < lo ? lo : (v > hi ? hi : v);

        public string Describe(Snapshot snap)
        {
            var sb = new StringBuilder();
            for (int i = 0; i < Routes.Count; i++)
            {
                sb.Append("L").Append(i + 1).Append(Loops[i] ? " (loop) " : " ")
                  .Append("[").Append(Locos[i]).Append("T/").Append(Cars[i]).Append("V] ");
                for (int k = 0; k < Routes[i].Count; k++)
                {
                    if (k > 0) sb.Append("-");
                    sb.Append(Routes[i][k]);
                }
                sb.AppendLine();
            }
            return sb.ToString();
        }
    }

    /// <summary>Decomposicao do custo, para a UI mostrar de onde vem o fitness.</summary>
    public struct EvalBreakdown
    {
        public double TravelCost;
        public double UnreachableCost;
        public double CongestionCost;
        public double StationLoadCost;
        public double TrackCost;
        public double CrossingCost;
        public double UnservedCost;

        public int UnreachablePairs;
        public int UnservedStations;
        public int CrossingsUsed;
        public float TrackLength;
        public float WorstLineUtil;
        public float AvgTravelTime;
    }
}
