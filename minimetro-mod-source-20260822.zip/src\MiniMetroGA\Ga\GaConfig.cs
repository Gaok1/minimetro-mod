namespace MiniMetroGA.Ga
{
    /// <summary>
    /// Todos os knobs do AG e da funcao de fitness. Tudo isso aparece na UI.
    /// Copiado por valor antes de cada run, entao mexer nos sliders enquanto
    /// roda nao corrompe a execucao em andamento.
    /// </summary>
    public class GaConfig
    {
        // ---- Algoritmo Genetico ----
        public int PopulationSize = 120;
        public int Generations = 400;
        public int Elitism = 4;
        public int TournamentSize = 4;
        public float CrossoverRate = 0.75f;
        public float MutationRate = 0.35f;
        public int MutationsPerGenome = 2;
        public int Seed = 0;                 // 0 = aleatorio
        public bool SeedFromCurrentNetwork = true;
        public int StagnationRestart = 80;   // geracoes sem melhora antes de injetar diversidade

        // ---- Espaco de busca ----
        public int MaxLinesOverride = 0;     // 0 = usa o limite da cidade
        public int MinStationsPerLine = 2;
        public int MaxStationsPerLine = 20;
        public bool AllowLoops = true;

        // ---- Modelo de demanda ----
        // A demanda vem da tabela de spawn do proprio jogo (ver SpawnModel), entao
        // DemandScale e so um ajuste fino em cima do valor real: 1.0 = o que o jogo faz.
        public float DemandScale = 1.0f;
        public float CrowdWeight = 0.15f;    // quanto as filas atuais inflam a demanda da estacao

        // ---- Modelo de simulacao ----
        // 0 = usa a velocidade real da cidade (City.Definition.TrainDefinition).
        // So mexa nisto para testar hipoteses; o valor lido do jogo esta certo.
        public float TrainSpeedOverride = 0f;
        public float DwellTime = 1.2f;       // segundos parado por estacao
        public float TransferPenalty = 12f;  // custo fixo de baldeacao, em segundos
        public float BoardingPenalty = 2f;   // custo fixo de embarque

        /// <summary>
        /// Segundo passe de roteamento em que a lotacao vira espera extra. E o que
        /// da sentido a um vagao: sem isso a capacidade nao afeta o tempo de ninguem
        /// e o AG distribui material rodante ao acaso. Custa ~2x o tempo de avaliacao.
        /// </summary>
        public bool CapacityFeedback = true;
        public float MaxCrowdingMultiplier = 4f;   // teto da espera extra por lotacao

        /// <summary>
        /// Quantos vagoes por locomotiva o AG pode propor. Nao e regra do jogo (o
        /// limite real e 64 por linha); e uma redea para o espaco de busca.
        /// </summary>
        public int MaxCarsPerLoco = 2;

        // ---- Pesos do fitness (tudo somado, menor = melhor) ----
        public float UnreachablePenalty = 900f;  // custo por par origem/forma sem rota
        public float CongestionWeight = 450f;    // penalidade por linha acima da capacidade
        public float StationLoadWeight = 260f;   // penalidade por estacao acima da capacidade
        public float TrackLengthWeight = 0.010f; // custo por unidade de trilho
        public float CrossingOverBudget = 1500f; // penalidade por tunel/ponte acima do orcamento
        public float UnservedStationPenalty = 350f; // estacao que ficou fora de toda linha

        public GaConfig Clone()
        {
            return (GaConfig)MemberwiseClone();
        }
    }
}
