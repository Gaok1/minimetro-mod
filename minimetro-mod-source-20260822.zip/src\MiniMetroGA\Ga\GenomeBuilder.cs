using System;
using System.Collections.Generic;
using MiniMetroGA.Core;

namespace MiniMetroGA.Ga
{
    /// <summary>
    /// Construtor de individuos iniciais.
    ///
    /// Populacao 100% aleatoria em problema de roteamento e desperdicio: quase todo
    /// individuo nasce invalido ou absurdo e o AG gasta centenas de geracoes so para
    /// chegar onde uma heuristica gulosa chega de graca. Entao semeamos com
    /// clusterizacao + vizinho mais proximo, e deixamos o AG fazer o refinamento.
    /// </summary>
    public class GenomeBuilder
    {
        private readonly Snapshot _s;
        private readonly GaConfig _cfg;
        private readonly int _maxLines;

        public GenomeBuilder(Snapshot snap, GaConfig cfg)
        {
            _s = snap;
            _cfg = cfg;
            _maxLines = Math.Max(1, cfg.MaxLinesOverride > 0
                ? Math.Min(cfg.MaxLinesOverride, snap.LineBudget)
                : snap.LineBudget);
        }

        /// <summary>Copia a rede que o jogador tem agora.</summary>
        public Genome FromCurrent(Random rng)
        {
            var g = new Genome();
            for (int i = 0; i < _s.CurrentRoutes.Count && i < _maxLines; i++)
            {
                g.Routes.Add(new List<int>(_s.CurrentRoutes[i]));
                g.Loops.Add(i < _s.CurrentLoop.Count && _s.CurrentLoop[i]);
                g.Locos.Add(1);
                g.Cars.Add(0);
            }
            if (g.RouteCount == 0) return RandomConstructive(rng);
            DistributeFleet(g, rng);
            return g;
        }

        /// <summary>
        /// k seeds aleatorios -> cada estacao vai pro seed mais proximo -> dentro do
        /// cluster monta a rota por vizinho mais proximo. Simples, rapido, e produz
        /// redes plausiveis desde a geracao zero.
        /// </summary>
        public Genome RandomConstructive(Random rng)
        {
            var g = new Genome();
            int k = 1 + rng.Next(_maxLines);
            if (k > _s.N / 2) k = Math.Max(1, _s.N / 2);

            // escolhe seeds bem espalhados (k-means++ simplificado)
            var seeds = new List<int>(k);
            seeds.Add(rng.Next(_s.N));
            while (seeds.Count < k)
            {
                int bestCand = -1;
                float bestDist = -1f;
                for (int attempt = 0; attempt < 8; attempt++)
                {
                    int cand = rng.Next(_s.N);
                    if (seeds.Contains(cand)) continue;
                    float nearest = float.MaxValue;
                    foreach (int sd in seeds)
                    {
                        float d = _s.Dist[cand][sd];
                        if (d < nearest) nearest = d;
                    }
                    if (nearest > bestDist) { bestDist = nearest; bestCand = cand; }
                }
                if (bestCand < 0) break;
                seeds.Add(bestCand);
            }
            k = seeds.Count;

            var clusters = new List<int>[k];
            for (int i = 0; i < k; i++) clusters[i] = new List<int>();

            for (int s = 0; s < _s.N; s++)
            {
                int best = 0;
                float bd = float.MaxValue;
                for (int i = 0; i < k; i++)
                {
                    float d = _s.Dist[s][seeds[i]];
                    if (d < bd) { bd = d; best = i; }
                }
                clusters[best].Add(s);
            }

            // clusters de 1 estacao sao inuteis: doa pro vizinho
            for (int i = 0; i < k; i++)
            {
                if (clusters[i].Count != 1) continue;
                int lone = clusters[i][0];
                int target = -1;
                float bd = float.MaxValue;
                for (int j = 0; j < k; j++)
                {
                    if (j == i || clusters[j].Count == 0) continue;
                    float d = _s.Dist[lone][clusters[j][0]];
                    if (d < bd) { bd = d; target = j; }
                }
                if (target >= 0) { clusters[target].Add(lone); clusters[i].Clear(); }
            }

            for (int i = 0; i < k; i++)
            {
                if (clusters[i].Count < 2) continue;
                var route = NearestNeighbourTour(clusters[i], rng);
                if (route.Count > _cfg.MaxStationsPerLine)
                    route.RemoveRange(_cfg.MaxStationsPerLine, route.Count - _cfg.MaxStationsPerLine);
                g.Routes.Add(route);
                g.Loops.Add(_cfg.AllowLoops && route.Count >= 3 && rng.Next(4) == 0);
                g.Locos.Add(1);
                g.Cars.Add(0);
            }

            if (g.RouteCount == 0)
            {
                var route = new List<int>();
                int a = rng.Next(_s.N);
                int b = (a + 1 + rng.Next(Math.Max(1, _s.N - 1))) % _s.N;
                route.Add(a); route.Add(b);
                g.Routes.Add(route); g.Loops.Add(false); g.Locos.Add(1); g.Cars.Add(0);
            }

            DistributeFleet(g, rng);
            return g;
        }

        private List<int> NearestNeighbourTour(List<int> members, Random rng)
        {
            var remaining = new List<int>(members);
            var tour = new List<int>(members.Count);
            int cur = remaining[rng.Next(remaining.Count)];
            remaining.Remove(cur);
            tour.Add(cur);
            while (remaining.Count > 0)
            {
                int best = 0;
                float bd = float.MaxValue;
                for (int i = 0; i < remaining.Count; i++)
                {
                    float d = _s.Dist[cur][remaining[i]];
                    if (d < bd) { bd = d; best = i; }
                }
                cur = remaining[best];
                remaining.RemoveAt(best);
                tour.Add(cur);
            }
            return tour;
        }

        /// <summary>
        /// 1 locomotiva por linha, e a sobra vai para quem tem mais demanda por assento.
        /// A sobra e o total MENOS uma por linha: o primeiro trem de cada linha ja
        /// sai do mesmo estoque (ver Genome.NormalizeFleet).
        ///
        /// Antes isto era sorteio puro, o que dava individuos iniciais com vagao numa
        /// linha vazia e trem sobrando numa linha lotada. Nao era fatal - o AG podia
        /// corrigir - mas comecar longe do obvio gasta geracoes a toa. Guardamos uma
        /// pitada de aleatoriedade para nao colapsar a diversidade da populacao.
        /// </summary>
        private void DistributeFleet(Genome g, Random rng)
        {
            int n = g.RouteCount;
            for (int i = 0; i < n; i++) { g.Locos[i] = 1; g.Cars[i] = 0; }

            int spareLocos = Math.Max(0, _s.Locomotives - n);
            for (int i = 0; i < spareLocos; i++)
            {
                int l = NeediestRoute(g, rng, requireCarSlot: false);
                if (l < 0) break;
                g.Locos[l]++;
            }
            for (int i = 0; i < _s.Carriages; i++)
            {
                int l = NeediestRoute(g, rng, requireCarSlot: true);
                if (l < 0) break;
                g.Cars[l]++;
            }
        }

        /// <summary>
        /// A rota com maior demanda por assento, com 1 chance em 4 de pegar uma
        /// qualquer - o suficiente para a populacao inicial nao virar clone.
        /// </summary>
        private int NeediestRoute(Genome g, Random rng, bool requireCarSlot)
        {
            int n = g.RouteCount;
            if (n == 0) return -1;

            if (rng.Next(4) == 0)
            {
                int r = rng.Next(n);
                if (Fits(g, r, requireCarSlot)) return r;
            }

            int best = -1;
            double bestScore = -1.0;
            for (int i = 0; i < n; i++)
            {
                if (!Fits(g, i, requireCarSlot)) continue;
                int seats = (g.Locos[i] + g.Cars[i]) * Math.Max(1, _s.RailcarCapacity);
                double score = g.RouteDemand(_s, i) / Math.Max(1, seats);
                if (score > bestScore) { bestScore = score; best = i; }
            }
            return best;
        }

        private bool Fits(Genome g, int route, bool requireCarSlot)
        {
            if (requireCarSlot) return g.Cars[route] < g.Locos[route] * _s.MaxCarsPerLoco;
            return g.Locos[route] < _s.MaxLocosFor(route);
        }
    }
}
