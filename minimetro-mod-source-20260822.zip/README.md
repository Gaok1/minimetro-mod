# MiniMetroGA

Mod do **Mini Metro** que otimiza a rede de metrô com um **algoritmo genético**.

- pausa o jogo, roda o AG numa thread separada e mostra a convergência ao vivo
- UI configurável: todos os parâmetros do AG e todos os pesos do fitness em slider
- overlay com os atalhos, que pisca a tecla apertada e mostra o AG progredindo
  mesmo com o painel fechado
- aplica a melhor solução construindo as linhas de verdade dentro do jogo
- modo automático: reotimiza e aplica sozinho a cada N segundos

## Atalhos

| Tecla | Ação |
|---|---|
| F8 | abre/fecha o painel |
| F9 | pausa/retoma o jogo |
| F10 | roda o AG |
| F11 | aplica a melhor solução |

## Estrutura

```
MiniMetroGA/
  bin/          MiniMetroGA.dll (o mod compilado)
  lib/          UnityEngine.IMGUIModule.dll não-stripada + netstandard.dll
  src/          código-fonte C#
  tools/        StripAudit — audita uma DLL contra a BCL stripada do jogo
  vault/        vault Obsidian com a documentação  ← comece por "00 - Índice"
  build.ps1
  MiniMetroGA.log
```

## Compilar

```powershell
.\build.ps1            # compila e instala
.\build.ps1 -Run -Tail # compila, abre o jogo e segue o log
```

Precisa apenas do .NET SDK no PATH.

## Documentação

Abra a pasta `vault/` no Obsidian (ou leia os `.md` direto). Comece por
`00 - Índice.md`. Se for mexer no código, leia antes
`Managed stripping - o problema central.md` — este build do jogo tem metade da
BCL removida e isso muda como tudo tem que ser escrito.

## Desinstalar

Apague `winhttp.dll`, `.doorstop_version`, `doorstop_config.ini` e esta pasta.
Nada dentro de `MiniMetro_Data/` foi modificado.
